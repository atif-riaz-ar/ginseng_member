<img class="login-logo" src="<?php echo assets_url("img/logo_original.png"); ?>" alt="lng-image"
	 style="width: 160px !important;">
