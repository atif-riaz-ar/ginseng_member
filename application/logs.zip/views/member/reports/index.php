<div id="appCapsule">
	<div class="listview-title mt-1"></div>
	<ul class="listview image-listview text inset">
		<li>
			<a href="<?php echo base_url("reports/ledger") ?>" class="item">
				<div class="in">
					[[LABEL_EWALLET_REPORT]]
				</div>
			</a>
		</li>
		<li>
			<a href="<?php echo base_url("reports/withdrawal") ?>" class="item">
				<div class="in">
					[[LABEL_WITHDRAWAL_LIST]]
				</div>
			</a>
		</li>
		<li>
			<a href="<?php echo base_url("reports/commissions") ?>" class="item">
				<div class="in">
					[[MBR_CAREER_REPORT]]
				</div>
			</a>
		</li>
	</ul>
</div>
