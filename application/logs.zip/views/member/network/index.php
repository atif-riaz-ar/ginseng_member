
<div id="appCapsule">
	<div class="listview-title mt-1"></div>
	<ul class="listview image-listview text inset">
		<li>
			<a href="<?php echo base_url("network/binary") ?>" class="item">
				<div class="in">
					[[LABEL_GENEOLOGY]]
				</div>
			</a>
		</li>
		<li>
			<a href="<?php echo base_url("network/sponsored") ?>" class="item">
				<div class="in">
					[[ADM_SPONSOR_TREE]]
				</div>
			</a>
		</li>
	</ul>

</div>
