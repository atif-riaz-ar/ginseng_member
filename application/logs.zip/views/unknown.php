<div id="appCapsule">
	<div class="section mt-2">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col-md-12">
						<div class="alert alert-warning">[[LABEL_UNKNOWN_ISSUE_FOUND]]</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
